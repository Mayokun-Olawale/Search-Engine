from search import search, title_length, article_count, random_article, favorite_article, multiple_keywords, display_result
from search_tests_helper import get_print, print_basic, print_advanced, print_advanced_option
from wiki import article_titles
from unittest.mock import patch
from unittest import TestCase, main

class TestSearch(TestCase):

    ##############
    # UNIT TESTS #
    ##############

    def test_example_unit_test(self):
        # Storing into a variable so don't need to copy and paste long list every time
        # If you want to store search results into a variable like this, make sure you pass a copy of it when
        # calling a function, otherwise the original list (ie the one stored in your variable) might be
        # mutated. To make a copy, you may use the .copy() function for the variable holding your search result.
        expected_dog_search_results = ['Edogawa, Tokyo', 'Kevin Cadogan', 'Endogenous cannabinoid', 'Black dog (ghost)', '2007 Bulldogs RLFC season', 'Mexican dog-faced bat', 'Dalmatian (dog)', 'Guide dog', '2009 Louisiana Tech Bulldogs football team', 'Georgia Bulldogs football', 'Endoglin', 'Sun dog', 'The Mandogs', 'Georgia Bulldogs football under Robert Winston', 'Landseer (dog)']
        self.assertEqual(search('dog'), expected_dog_search_results)

    ''' 
    This test is for the function search. The function should take a string argument and check through the list of titles and return a list of articles that contains the word inputed
    '''
    def test_search(self):
        expected_music_search_results = ['List of Canadian musicians', 'French pop music', 'Noise (music)', '1922 in music', '1986 in music', '2009 in music', 'Rock music', 'Lights (musician)', 'List of soul musicians', 'Aube (musician)', 'List of overtone musicians', 'Tim Arnold (musician)', 'Peter Brown (music industry)', 'Old-time music', 'Arabic music', 'List of Saturday Night Live musical sketches', 'Joe Becker (musician)', 'Aco (musician)', 'Geoff Smith (British musician)', 'Richard Wright (musician)', 'Voice classification in non-classical music', '1936 in music', '1962 in country music', 'List of dystopian music, TV programs, and games', 'Steve Perry (musician)', 'David Gray (musician)', 'Annie (musical)', 'Alex Turner (musician)', 'List of gospel musicians', 'Tom Hooper (musician)', 'Indian classical music', '1996 in music', 'Joseph Williams (musician)', 'The Hunchback of Notre Dame (musical)', 'English folk music (1500–1899)', 'David Levi (musician)', 'George Crum (musician)', 'Traditional Thai musical instruments', 'Charles McPherson (musician)', 'Les Cousins (music club)', 'Paul Carr (musician)', '2006 in music', 'Sean Delaney (musician)', 'Tony Kaye (musician)', 'Danja (musician)', 'Texture (music)', 'Register (music)', '2007 in music', '2008 in music']
        self.assertEqual(search('mUsiC'), expected_music_search_results)
        expected_7_search_results = ['2007 Bulldogs RLFC season', '2007 in music']
        self.assertEqual(search('7'), expected_7_search_results)
        expected_empty_search_results = []
        self.assertEqual(search(''), expected_empty_search_results)
        expected_flower_search_results = []
        self.assertEqual(search('flower'), expected_flower_search_results)

    '''
    This test is for the function title_length. This function takes a number argument and looks through the list of titles and only returns titles that have the same length or less of what the user inputs
    '''
    def test_title_length(self):
        music_search_results = ['List of Canadian musicians', 'French pop music', 'Noise (music)', '1922 in music',
                            '1986 in music', '2009 in music', 'Rock music', 'Lights (musician)',
                            'List of soul musicians', 'Aube (musician)', 'List of overtone musicians',
                            'Tim Arnold (musician)', 'Peter Brown (music industry)', 'Old-time music', 'Arabic music',
                            'List of Saturday Night Live musical sketches', 'Joe Becker (musician)', 'Aco (musician)',
                            'Geoff Smith (British musician)', 'Richard Wright (musician)',
                            'Voice classification in non-classical music', '1936 in music', '1962 in country music',
                            'List of dystopian music, TV programs, and games', 'Steve Perry (musician)',
                            'David Gray (musician)', 'Annie (musical)', 'Alex Turner (musician)',
                            'List of gospel musicians', 'Tom Hooper (musician)', 'Indian classical music',
                            '1996 in music', 'Joseph Williams (musician)', 'The Hunchback of Notre Dame (musical)',
                            'English folk music (1500–1899)', 'David Levi (musician)', 'George Crum (musician)',
                            'Traditional Thai musical instruments', 'Charles McPherson (musician)',
                            'Les Cousins (music club)', 'Paul Carr (musician)', '2006 in music',
                            'Sean Delaney (musician)', 'Tony Kaye (musician)', 'Danja (musician)', 'Texture (music)',
                            'Register (music)', '2007 in music', '2008 in music']
        self.assertEqual(title_length(20, music_search_results),
                     ['French pop music', 'Noise (music)', '1922 in music', '1986 in music', '2009 in music',
                      'Rock music', 'Lights (musician)', 'Aube (musician)', 'Old-time music', 'Arabic music',
                      'Aco (musician)', '1936 in music', 'Annie (musical)', '1996 in music', 'Paul Carr (musician)',
                      '2006 in music', 'Tony Kaye (musician)', 'Danja (musician)', 'Texture (music)',
                      'Register (music)', '2007 in music', '2008 in music'])
        seven_search_results = ['2007 Bulldogs RLFC season', '2007 in music']
        self.assertEqual(title_length(0, seven_search_results), [])
        empty_search_results = []
        self.assertEqual(title_length(50, empty_search_results), [])
    
    '''
    This test is for the function article_count. This function should take a number as an argument and return the number of articles requested. If the number is greater than the number of articles in the list, the whole list is returned.
    '''
    def test_article_count(self):
        music_search_results = ['List of Canadian musicians', 'French pop music', 'Noise (music)', '1922 in music',
                            '1986 in music', '2009 in music', 'Rock music', 'Lights (musician)',
                            'List of soul musicians', 'Aube (musician)', 'List of overtone musicians',
                            'Tim Arnold (musician)', 'Peter Brown (music industry)', 'Old-time music', 'Arabic music',
                            'List of Saturday Night Live musical sketches', 'Joe Becker (musician)', 'Aco (musician)',
                            'Geoff Smith (British musician)', 'Richard Wright (musician)',
                            'Voice classification in non-classical music', '1936 in music', '1962 in country music',
                            'List of dystopian music, TV programs, and games', 'Steve Perry (musician)',
                            'David Gray (musician)', 'Annie (musical)', 'Alex Turner (musician)',
                            'List of gospel musicians', 'Tom Hooper (musician)', 'Indian classical music',
                            '1996 in music', 'Joseph Williams (musician)', 'The Hunchback of Notre Dame (musical)',
                            'English folk music (1500–1899)', 'David Levi (musician)', 'George Crum (musician)',
                            'Traditional Thai musical instruments', 'Charles McPherson (musician)',
                            'Les Cousins (music club)', 'Paul Carr (musician)', '2006 in music',
                            'Sean Delaney (musician)', 'Tony Kaye (musician)', 'Danja (musician)', 'Texture (music)',
                            'Register (music)', '2007 in music', '2008 in music']
        self.assertEqual(article_count(10, music_search_results),
                     ['List of Canadian musicians', 'French pop music', 'Noise (music)', '1922 in music',
                      '1986 in music', '2009 in music', 'Rock music', 'Lights (musician)', 'List of soul musicians',
                      'Aube (musician)'])
        seven_search_results = ['2007 Bulldogs RLFC season', '2007 in music']
        self.assertEqual(article_count(50, seven_search_results), ['2007 Bulldogs RLFC season', '2007 in music'])
        tea_search_results = ['Spain national beach soccer team', '2009 Louisiana Tech Bulldogs football team',
                          "United States men's national soccer team 2009 results", 'China national soccer team']
        self.assertEqual(article_count(-7, tea_search_results), [])
        book_search_results = []
        self.assertEqual(article_count(55, book_search_results), [])

    '''
    This test is for the function random_article. This function takes in a number arguement and a list of titles. It returns the article at the index of the number given from the list of titles. If the number is a negative number or is larger than the amount of articles it returns nothing.
    '''
    def test_random_article(self):
        music_search_results = ['List of Canadian musicians', 'French pop music', 'Noise (music)', '1922 in music',
                            '1986 in music', '2009 in music', 'Rock music', 'Lights (musician)',
                            'List of soul musicians', 'Aube (musician)', 'List of overtone musicians',
                            'Tim Arnold (musician)', 'Peter Brown (music industry)', 'Old-time music', 'Arabic music',
                            'List of Saturday Night Live musical sketches', 'Joe Becker (musician)', 'Aco (musician)',
                            'Geoff Smith (British musician)', 'Richard Wright (musician)',
                            'Voice classification in non-classical music', '1936 in music', '1962 in country music',
                            'List of dystopian music, TV programs, and games', 'Steve Perry (musician)',
                            'David Gray (musician)', 'Annie (musical)', 'Alex Turner (musician)',
                            'List of gospel musicians', 'Tom Hooper (musician)', 'Indian classical music',
                            '1996 in music', 'Joseph Williams (musician)', 'The Hunchback of Notre Dame (musical)',
                            'English folk music (1500–1899)', 'David Levi (musician)', 'George Crum (musician)',
                            'Traditional Thai musical instruments', 'Charles McPherson (musician)',
                            'Les Cousins (music club)', 'Paul Carr (musician)', '2006 in music',
                            'Sean Delaney (musician)', 'Tony Kaye (musician)', 'Danja (musician)', 'Texture (music)',
                            'Register (music)', '2007 in music', '2008 in music']
        self.assertEqual(random_article(7, music_search_results), 'Lights (musician)')
        seven_search_results = ['2007 Bulldogs RLFC season', '2007 in music']
        self.assertEqual(random_article(-7, seven_search_results), '')
        book_search_results = []
        self.assertEqual(random_article(10, book_search_results), '')
    
    '''
    This test is for the function favorite_article. This fuction takes an article name and a list of titles. It returns true if the article name is in list and False if it is not.
    '''
    def test_favorite_articles(self):
        music_search_results = ['List of Canadian musicians', 'French pop music', 'Noise (music)', '1922 in music',
                            '1986 in music', '2009 in music', 'Rock music', 'Lights (musician)',
                            'List of soul musicians', 'Aube (musician)', 'List of overtone musicians',
                            'Tim Arnold (musician)', 'Peter Brown (music industry)', 'Old-time music', 'Arabic music',
                            'List of Saturday Night Live musical sketches', 'Joe Becker (musician)', 'Aco (musician)',
                            'Geoff Smith (British musician)', 'Richard Wright (musician)',
                            'Voice classification in non-classical music', '1936 in music', '1962 in country music',
                            'List of dystopian music, TV programs, and games', 'Steve Perry (musician)',
                            'David Gray (musician)', 'Annie (musical)', 'Alex Turner (musician)',
                            'List of gospel musicians', 'Tom Hooper (musician)', 'Indian classical music',
                            '1996 in music', 'Joseph Williams (musician)', 'The Hunchback of Notre Dame (musical)',
                            'English folk music (1500–1899)', 'David Levi (musician)', 'George Crum (musician)',
                            'Traditional Thai musical instruments', 'Charles McPherson (musician)',
                            'Les Cousins (music club)', 'Paul Carr (musician)', '2006 in music',
                            'Sean Delaney (musician)', 'Tony Kaye (musician)', 'Danja (musician)', 'Texture (music)',
                            'Register (music)', '2007 in music', '2008 in music']
        self.assertEqual(favorite_article('2008 In MuSiC', music_search_results), True)
        seven_search_results = ['2007 Bulldogs RLFC season', '2007 in music']
        self.assertEqual(favorite_article('2007', seven_search_results), False)
        music_search_results = ['List of Canadian musicians', 'French pop music', 'Noise (music)', '1922 in music',
                            '1986 in music', '2009 in music', 'Rock music', 'Lights (musician)',
                            'List of soul musicians', 'Aube (musician)', 'List of overtone musicians',
                            'Tim Arnold (musician)', 'Peter Brown (music industry)', 'Old-time music', 'Arabic music',
                            'List of Saturday Night Live musical sketches', 'Joe Becker (musician)', 'Aco (musician)',
                            'Geoff Smith (British musician)', 'Richard Wright (musician)',
                            'Voice classification in non-classical music', '1936 in music', '1962 in country music',
                            'List of dystopian music, TV programs, and games', 'Steve Perry (musician)',
                            'David Gray (musician)', 'Annie (musical)', 'Alex Turner (musician)',
                            'List of gospel musicians', 'Tom Hooper (musician)', 'Indian classical music',
                            '1996 in music', 'Joseph Williams (musician)', 'The Hunchback of Notre Dame (musical)',
                            'English folk music (1500–1899)', 'David Levi (musician)', 'George Crum (musician)',
                            'Traditional Thai musical instruments', 'Charles McPherson (musician)',
                            'Les Cousins (music club)', 'Paul Carr (musician)', '2006 in music',
                            'Sean Delaney (musician)', 'Tony Kaye (musician)', 'Danja (musician)', 'Texture (music)',
                            'Register (music)', '2007 in music', '2008 in music']
        self.assertEqual(favorite_article('', music_search_results), False)


    '''
    This test is for the function multiple_keywords. This function takes in a string and a list of articles. It then uses the search function to look for articles that contain the inputed string. It then returns a list that combines the articles found using the search function and the original titles given.
    '''
    def test_multiple_keywords(self):
        music_search_results = ['List of Canadian musicians', 'French pop music', 'Noise (music)', '1922 in music',
                            '1986 in music', '2009 in music', 'Rock music', 'Lights (musician)',
                            'List of soul musicians', 'Aube (musician)', 'List of overtone musicians',
                            'Tim Arnold (musician)', 'Peter Brown (music industry)', 'Old-time music', 'Arabic music',
                            'List of Saturday Night Live musical sketches', 'Joe Becker (musician)', 'Aco (musician)',
                            'Geoff Smith (British musician)', 'Richard Wright (musician)',
                            'Voice classification in non-classical music', '1936 in music', '1962 in country music',
                            'List of dystopian music, TV programs, and games', 'Steve Perry (musician)',
                            'David Gray (musician)', 'Annie (musical)', 'Alex Turner (musician)',
                            'List of gospel musicians', 'Tom Hooper (musician)', 'Indian classical music',
                            '1996 in music', 'Joseph Williams (musician)', 'The Hunchback of Notre Dame (musical)',
                            'English folk music (1500–1899)', 'David Levi (musician)', 'George Crum (musician)',
                            'Traditional Thai musical instruments', 'Charles McPherson (musician)',
                            'Les Cousins (music club)', 'Paul Carr (musician)', '2006 in music',
                            'Sean Delaney (musician)', 'Tony Kaye (musician)', 'Danja (musician)', 'Texture (music)',
                            'Register (music)', '2007 in music', '2008 in music']
        seven_search_results = ['2007 Bulldogs RLFC season', '2007 in music']
        self.assertEqual(multiple_keywords('7', music_search_results),
                     ['List of Canadian musicians', 'French pop music', 'Noise (music)', '1922 in music',
                      '1986 in music', '2009 in music', 'Rock music', 'Lights (musician)', 'List of soul musicians',
                      'Aube (musician)', 'List of overtone musicians', 'Tim Arnold (musician)',
                      'Peter Brown (music industry)', 'Old-time music', 'Arabic music',
                      'List of Saturday Night Live musical sketches', 'Joe Becker (musician)', 'Aco (musician)',
                      'Geoff Smith (British musician)', 'Richard Wright (musician)',
                      'Voice classification in non-classical music', '1936 in music', '1962 in country music',
                      'List of dystopian music, TV programs, and games', 'Steve Perry (musician)',
                      'David Gray (musician)', 'Annie (musical)', 'Alex Turner (musician)', 'List of gospel musicians',
                      'Tom Hooper (musician)', 'Indian classical music', '1996 in music', 'Joseph Williams (musician)',
                      'The Hunchback of Notre Dame (musical)', 'English folk music (1500–1899)',
                      'David Levi (musician)', 'George Crum (musician)', 'Traditional Thai musical instruments',
                      'Charles McPherson (musician)', 'Les Cousins (music club)', 'Paul Carr (musician)',
                      '2006 in music', 'Sean Delaney (musician)', 'Tony Kaye (musician)', 'Danja (musician)',
                      'Texture (music)', 'Register (music)', '2007 in music', '2008 in music',
                      '2007 Bulldogs RLFC season', '2007 in music'])
        fisk_search_results = ['Fiskerton, Lincolnshire', 'Fisk University']
        flower_search_results = []
        self.assertEqual(multiple_keywords('flower', fisk_search_results), ['Fiskerton, Lincolnshire', 'Fisk University'])
        hello_search_results = []
        empty_search_results = []
        self.assertEqual(multiple_keywords('', hello_search_results), [])
   
        




        




    #####################
    # INTEGRATION TESTS #
    #####################

    @patch('builtins.input')
    def test_example_integration_test(self, input_mock):
        keyword = 'dog'
        advanced_option = 6

        # Output of calling display_results() with given user input. If a different
        # advanced option is included, append further user input to this list (after `advanced_option`)
        output = get_print(input_mock, [keyword, advanced_option])
        # Expected print outs from running display_results() with above user input
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + "\nHere are your articles: ['Edogawa, Tokyo', 'Kevin Cadogan', 'Endogenous cannabinoid', 'Black dog (ghost)', '2007 Bulldogs RLFC season', 'Mexican dog-faced bat', 'Dalmatian (dog)', 'Guide dog', '2009 Louisiana Tech Bulldogs football team', 'Georgia Bulldogs football', 'Endoglin', 'Sun dog', 'The Mandogs', 'Georgia Bulldogs football under Robert Winston', 'Landseer (dog)']\n"

        # Test whether calling display_results() with given user input equals expected printout
        self.assertEqual(output, expected)
    ''' 
    This test is for the function search. The function should take a string argument and check through the list of titles and return a list of articles that contains the word inputed
    '''
    @patch('builtins.input')
    def test_integration_search(self, input_mock):
        keyword = 'all'
        advanced_option = 6
        output = get_print(input_mock, [keyword, advanced_option])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + "\nHere are your articles: ['USC Trojans volleyball', '2009 Louisiana Tech Bulldogs football team', 'Georgia Bulldogs football', 'Mets de Guaynabo (volleyball)', 'Georgia Bulldogs football under Robert Winston']\n"
        self.assertEqual(output, expected)
    ''' 
    This test is an edgecase for the function search. The function should take a string argument and check through the list of titles and return a list of articles that contains the word inputed. If the string is empty it should return nothing.
    '''
    @patch('builtins.input')
    def test_integration_search_empty_string(self, input_mock):
        keyword = ''
        advanced_option = 6
        output = get_print(input_mock, [keyword, advanced_option])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + "\nNo articles found\n"
        self.assertEqual(output, expected)

    '''
    This test is for the function title_length. This function takes a number argument and looks through the list of titles and only returns titles that have the same length or less of what the user inputs.
    '''
    @patch('builtins.input')
    def test_integration_title_length(self, input_mock):
        keyword = 'ma'
        title_length = 15
        advanced_option = 1
        output = get_print(input_mock, [keyword, advanced_option, title_length])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + str(title_length) + '\n' + "\nHere are your articles: ['Human computer', 'Dalmatian (dog)', 'The Mandogs']\n"
        self.assertEqual(output, expected)

    '''
    This test is an edgecase for the function title_length. This function takes a number argument and looks through the list of titles and only returns titles that have the same length or less of what the user inputs. If the number inputed is less than the length of any article, nothing is returned.
    '''
    @patch('builtins.input')
    def test_integration_title_length_zero_length(self, input_mock):
        keyword = 'ay'
        title_length = 0
        advanced_option = 1
        output = get_print(input_mock, [keyword, advanced_option, title_length])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + str(title_length) + '\n' + "\nNo articles found\n"
        self.assertEqual(output, expected)

    '''
    This test is for the function article_count. This function should take a number as an argument and return the number of articles requested. If the number is greater than the number of articles in the list, the whole list is returned.
    '''
    @patch('builtins.input')
    def test_integration_article_count_less_number(self, input_mock):
        keyword = 'ok'
        article_count = 5
        advanced_option = 2
        output = get_print(input_mock, [keyword, advanced_option, article_count])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + str(article_count) + '\n' + "\nHere are your articles: ['Edogawa, Tokyo']\n"
        self.assertEqual(output, expected)

    '''
    This test is for the function article_count. This function should take a number as an argument and return the number of articles requested. If the number is greater than the number of articles in the list, the whole list is returned.
    '''
    @patch('builtins.input')
    def test_integration_article_count(self, input_mock):
        keyword = 'music'
        article_count = 3
        advanced_option = 2
        output = get_print(input_mock, [keyword, advanced_option, article_count])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + str(article_count) + '\n' + "\nHere are your articles: ['List of Canadian musicians', 'French pop music', 'Noise (music)']\n"
        self.assertEqual(output, expected)

    '''
    This test is for the function random_article. This function takes in a number arguement and a list of titles. It returns the article at the index of the number given from the list of titles. If the number is a negative number or is larger than the amount of articles it returns nothing.
    '''
    @patch('builtins.input')
    def test_integration_random_article(self, input_mock):
        keyword = 'mo'
        random_article = 0
        advanced_option = 3
        output = get_print(input_mock, [keyword, advanced_option, random_article])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + str(random_article) + '\n' + "\nHere are your articles: Mode (computer interface)\n"
        self.assertEqual(output, expected)

    '''
    This test is for the function random_article. This function takes in a number arguement and a list of titles. It returns the article at the index of the number given from the list of titles. If the number is a negative number or is larger than the amount of articles it returns nothing.
    '''
    @patch('builtins.input')
    def test_integration_random_article_over_index(self, input_mock):
        keyword = 'me'
        random_article = 50
        advanced_option = 3
        output = get_print(input_mock, [keyword, advanced_option, random_article])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + str(random_article) + '\n' + "\nNo articles found\n"
        self.assertEqual(output, expected)

    '''
    This test is for the function favorite_article. This fuction takes an article name and a list of titles. It returns true if the article name is in list and False if it is not.
    '''
    @patch('builtins.input')
    def test_integration_favorite_article(self, input_mock):
        keyword = 'jo'
        favorite_article = 'Joe Becker (musician)'
        advanced_option = 4
        output = get_print(input_mock, [keyword, advanced_option, favorite_article])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + favorite_article + "\n" + "\nHere are your articles: ['Joe Becker (musician)', 'Will Johnson (soccer)', 'Joseph Williams (musician)']" + "\nYour favorite article is in the returned articles!\n"
        self.assertEqual(output, expected)

    '''
    This test is for the function favorite_article. This fuction takes an article name and a list of titles. It returns true if the article name is in list and False if it is not.
    '''
    @patch('builtins.input')
    def test_integration_favorite_article_empty_string(self, input_mock):
        keyword = 'he'
        favorite_article = ''
        advanced_option = 4
        output = get_print(input_mock, [keyword, advanced_option, favorite_article])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + favorite_article + "\n" + "\nHere are your articles: ['List of Saturday Night Live musical sketches', 'Steven Cohen (soccer)', 'The Hunchback of Notre Dame (musical)', 'The Mandogs', 'Charles McPherson (musician)']" + "\nYour favorite article is not in the returned articles!\n"
        self.assertEqual(output, expected)

    '''
    This test is for the function multiple_keywords. This function takes in a string and a list of articles. It then uses the search function to look for articles that contain the inputed string. It then returns a list that combines the articles found using the search function and the original titles given.
    '''
    @patch('builtins.input')
    def test_integration_multiple_keywords(self, input_mock):
        keyword = 'cat'
        multiple_keywords = 'fisk'
        advanced_option = 5
        output = get_print(input_mock, [keyword, advanced_option, multiple_keywords])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + multiple_keywords + "\n" + "\nHere are your articles: ['Voice classification in non-classical music', 'Fiskerton, Lincolnshire', 'Fisk University']\n"
        self.assertEqual(output, expected)

    '''
    This test is for the function multiple_keywords. This function takes in a string and a list of articles. It then uses the search function to look for articles that contain the inputed string. It then returns a list that combines the articles found using the search function and the original titles given.
    '''
    @patch('builtins.input')
    def test_integration_multiple_keywords_no_result(self, input_mock):
        keyword = 'be'
        multiple_keywords = 'flower'
        advanced_option = 5
        output = get_print(input_mock, [keyword, advanced_option, multiple_keywords])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + multiple_keywords + "\n" + "\nHere are your articles: ['Spain national beach soccer team', 'Aube (musician)', 'Joe Becker (musician)', 'Georgia Bulldogs football under Robert Winston']\n"
        self.assertEqual(output, expected)

    



    


    

    


# Write tests above this line. Do not remove.
if __name__ == "__main__":
    main()
