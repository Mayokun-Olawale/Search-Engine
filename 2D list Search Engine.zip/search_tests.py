from search import search, article_length, unique_authors, most_recent_article, favorite_author, title_and_author, refine_search, display_result
from search_tests_helper import get_print, print_basic, print_advanced, print_advanced_option
from wiki import article_metadata
from unittest.mock import patch
from unittest import TestCase, main

class TestSearch(TestCase):

    ##############
    # UNIT TESTS #
    ##############

    def test_example_unit_test(self):
        expected_search_soccer_results = [
            ['Spain national beach soccer team', 'jack johnson', 1233458894, 1526],
            ['Will Johnson (soccer)', 'Burna Boy', 1218489712, 3562],
            ['Steven Cohen (soccer)', 'Mack Johnson', 1237669593, 2117]
        ]
        self.assertEqual(search('soccer'), expected_search_soccer_results)
    
    '''
    This function tests the function search, this function takes in one argument and returns a 2D list of all the articles relqated to said keyword
    '''
    def test_search(self):
        expected_search_club = [['Dalmatian (dog)', 'Mr Jake', 1207793294, 26582], ['Steven Cohen (soccer)', 'Mack Johnson', 1237669593, 2117], ['Les Cousins (music club)', 'Mack Johnson', 1187072433, 4926]]
        self.assertEqual(search('cLuB'), expected_search_club)
        expected_search_flower = []
        self.assertEqual(search('flower'), expected_search_flower)
        expected_search_empty_string = []
        self.assertEqual(search(''), expected_search_empty_string)

    '''
    This function tests the function article_length. This function takes in 2 arguments, one integer(max length) and one 2D list(metadat). It looks through the 2D list and returns a 2D list of articles that have a length equal to or less than the max length given.
    '''
    def test_article_length(self):
        and_search_results = [['List of Canadian musicians', 'Jack Johnson', 1181623340, 21023], ['French pop music', 'Mack Johnson', 1172208041, 5569], ['Edogawa, Tokyo', 'jack johnson', 1222607041, 4526], ['Noise (music)', 'jack johnson', 1194207604, 15641], ['1922 in music', 'Gary King', 1242717698, 11576], ['Ken Kennedy (computer scientist)', 'Mack Johnson', 1246308670, 4144], ['1986 in music', 'jack johnson', 1048918054, 6632], ['Kevin Cadogan', 'Mr Jake', 1144136316, 3917], ['2009 in music', 'RussBot', 1235133583, 69451], ['Rock music', 'Mack Johnson', 1258069053, 119498], ['Lights (musician)', 'Burna Boy', 1213914297, 5898], ['Human computer', 'Bearcat', 1248275178, 4750], ['Aube (musician)', 'Mack Johnson', 1145410600, 3152], ['List of overtone musicians', 'Mack Johnson', 1176928050, 2299], ['Black dog (ghost)', 'Pegship', 1220471117, 14746], ['USC Trojans volleyball', 'jack johnson', 1218049435, 5525], ['Tim Arnold (musician)', 'jack johnson', 1181480380, 4551], ['2007 Bulldogs RLFC season', 'Burna Boy', 1177410119, 11116], ['Peter Brown (music industry)', 'Pegship', 1240235639, 2837], ['Mexican dog-faced bat', 'Mack Johnson', 1255316429, 1138], ['Embryo drawing', 'Jack Johnson', 1034459202, 1712], ['Old-time music', 'Nihonjoe', 1124771619, 12755], ['Arabic music', 'RussBot', 1209417864, 25114], ['C Sharp (programming language)', 'Burna Boy', 1232492672, 52364], ['Joe Becker (musician)', 'Nihonjoe', 1203234507, 5842], ['Will Johnson (soccer)', 'Burna Boy', 1218489712, 3562], ['Fiskerton, Lincolnshire', 'Bearcat', 1259869948, 5853], ['B (programming language)', 'jack johnson', 1196622610, 5482], ['Richard Wright (musician)', 'RussBot', 1189536295, 16185], ['Voice classification in non-classical music', 'RussBot', 1198092852, 11280], ['Dalmatian (dog)', 'Mr Jake', 1207793294, 26582], ['1936 in music', 'RussBot', 1243745950, 23417], ['Guide dog', 'Jack Johnson', 1165601603, 7339], ['1962 in country music', 'Mack Johnson', 1249862464, 7954], ['List of dystopian music, TV programs, and games', 'Bearcat', 1165317338, 13458], ['Steven Cohen (soccer)', 'Mack Johnson', 1237669593, 2117], ['Steve Perry (musician)', 'Nihonjoe', 1254812045, 22204], ['David Gray (musician)', 'jack johnson', 1159841492, 7203], ['Georgia Bulldogs football', 'Burna Boy', 1166567889, 43718], ['Time travel', 'Jack Johnson', 1140826049, 35170], ['Fisk University', 'RussBot', 1263393671, 16246], ['Annie (musical)', 'Jack Johnson', 1223619626, 27558], ['Alex Turner (musician)', 'jack johnson', 1187010135, 9718], ['Python (programming language)', 'Burna Boy', 1137530195, 41571], ['Tom Hooper (musician)', 'Bearcat', 1204967541, 1441], ['Endoglin', 'Bearcat', 1212259031, 6778], ['Indian classical music', 'Burna Boy', 1222543238, 9503], ['Sun dog', 'Mr Jake', 1208969289, 18050], ['1996 in music', 'Nihonjoe', 1148585201, 21688], ['Lua (programming language)', 'Burna Boy', 1113957128, 0], ['Single-board computer', 'Gary King', 1220260601, 8271], ['Joseph Williams (musician)', 'Pegship', 1140752684, 4253], ['The Hunchback of Notre Dame (musical)', 'Nihonjoe', 1192176615, 42], ['Covariance and contravariance (computer science)', 'Bearcat', 1167547364, 7453], ['English folk music (1500–1899)', 'Bearcat', 1177634764, 2073], ['Personal computer', 'Pegship', 1220391790, 45663], ['The Mandogs', 'Mack Johnson', 1205282029, 3968], ['Scores (computer virus)', 'RussBot', 1235850703, 2706], ['Digital photography', 'Mr Jake', 1095727840, 18093], ['George Crum (musician)', 'jack johnson', 1252996687, 3848], ['Wildlife photography', 'Jack Johnson', 1165248747, 1410], ['Traditional Thai musical instruments', 'Jack Johnson', 1191830919, 6775], ['Landseer (dog)', 'Bearcat', 1231438650, 2006], ['Comparison of programming languages (basic instructions)', 'RussBot', 1238781354, 61644], ['Les Cousins (music club)', 'Mack Johnson', 1187072433, 4926], ['Paul Carr (musician)', 'Burna Boy', 1254142018, 5716], ['2006 in music', 'Jack Johnson', 1171547747, 105280], ['Spawning (computer gaming)', 'jack johnson', 1176750529, 3413], ['Sean Delaney (musician)', 'Nihonjoe', 1204328174, 5638], ['Tony Kaye (musician)', 'Burna Boy', 1141489894, 8419], ['Danja (musician)', 'RussBot', 1257155543, 6925], ['Ruby (programming language)', 'Bearcat', 1193928035, 30284], ['Texture (music)', 'Bearcat', 1161070178, 3626], ['Register (music)', 'Pegship', 1082665179, 598], ['Mode (computer interface)', 'Pegship', 1182732608, 2991], ['2007 in music', 'Bearcat', 1169248845, 45652], ['2008 in music', 'Burna Boy', 1217641857, 107605], ['Semaphore (programming)', 'Nihonjoe', 1144850850, 7616], ["Wake Forest Demon Deacons men's soccer", 'Burna Boy', 1260577388, 26745]] 
        self.assertEqual(article_length(200, and_search_results), [['Lua (programming language)', 'Burna Boy', 1113957128, 0], ['The Hunchback of Notre Dame (musical)', 'Nihonjoe', 1192176615, 42]])
        music_search_result = [['List of Canadian musicians', 'Jack Johnson', 1181623340, 21023], ['French pop music', 'Mack Johnson', 1172208041, 5569], ['Noise (music)', 'jack johnson', 1194207604, 15641], ['1922 in music', 'Gary King', 1242717698, 11576], ['1986 in music', 'jack johnson', 1048918054, 6632], ['Kevin Cadogan', 'Mr Jake', 1144136316, 3917], ['2009 in music', 'RussBot', 1235133583, 69451], ['Rock music', 'Mack Johnson', 1258069053, 119498], ['Lights (musician)', 'Burna Boy', 1213914297, 5898], ['Tim Arnold (musician)', 'jack johnson', 1181480380, 4551], ['Old-time music', 'Nihonjoe', 1124771619, 12755], ['Arabic music', 'RussBot', 1209417864, 25114], ['Joe Becker (musician)', 'Nihonjoe', 1203234507, 5842], ['Richard Wright (musician)', 'RussBot', 1189536295, 16185], ['Voice classification in non-classical music', 'RussBot', 1198092852, 11280], ['1936 in music', 'RussBot', 1243745950, 23417], ['1962 in country music', 'Mack Johnson', 1249862464, 7954], ['List of dystopian music, TV programs, and games', 'Bearcat', 1165317338, 13458], ['Steve Perry (musician)', 'Nihonjoe', 1254812045, 22204], ['David Gray (musician)', 'jack johnson', 1159841492, 7203], ['Alex Turner (musician)', 'jack johnson', 1187010135, 9718], ['List of gospel musicians', 'Nihonjoe', 1197658845, 3805], ['Indian classical music', 'Burna Boy', 1222543238, 9503], ['1996 in music', 'Nihonjoe', 1148585201, 21688], ['Traditional Thai musical instruments', 'Jack Johnson', 1191830919, 6775], ['2006 in music', 'Jack Johnson', 1171547747, 105280], ['Tony Kaye (musician)', 'Burna Boy', 1141489894, 8419], ['Texture (music)', 'Bearcat', 1161070178, 3626], ['2007 in music', 'Bearcat', 1169248845, 45652], ['2008 in music', 'Burna Boy', 1217641857, 107605]]
        self.assertEqual(article_length(100000000000000000000, music_search_result), music_search_result)
        empty_string_search_result = []
        self.assertEqual(article_length(5000000, empty_string_search_result), [])
    
    '''
    This function tests the function unique_authors. This function takes in 2 arguments, one integer(the count) and one 2D list(metadata). It returns a 2D list with the count amount of articles all with different authors.
    '''
    def test_unique_authors(self):
        film_search_result = [['List of Canadian musicians', 'Jack Johnson', 1181623340, 21023], ['Joe Becker (musician)', 'Nihonjoe', 1203234507, 5842], ['Geoff Smith (British musician)', 'Pegship', 1194687509, 2043], ['1936 in music', 'RussBot', 1243745950, 23417], ['Annie (musical)', 'Jack Johnson', 1223619626, 27558], ['Joseph Williams (musician)', 'Pegship', 1140752684, 4253], ['The Hunchback of Notre Dame (musical)', 'Nihonjoe', 1192176615, 42], ['Digital photography', 'Mr Jake', 1095727840, 18093], ['2006 in music', 'Jack Johnson', 1171547747, 105280]]
        self.assertEqual(unique_authors(100, film_search_result), [['List of Canadian musicians', 'Jack Johnson', 1181623340, 21023], ['Joe Becker (musician)', 'Nihonjoe', 1203234507, 5842], ['Geoff Smith (British musician)', 'Pegship', 1194687509, 2043], ['1936 in music', 'RussBot', 1243745950, 23417], ['Digital photography', 'Mr Jake', 1095727840, 18093]])
        team_search_result = [['USC Trojans volleyball', 'jack johnson', 1218049435, 5525], ['Will Johnson (soccer)', 'Burna Boy', 1218489712, 3562], ['2009 Louisiana Tech Bulldogs football team', 'Nihonjoe', 1245796406, 22410], ['Georgia Bulldogs football', 'Burna Boy', 1166567889, 43718], ['Spawning (computer gaming)', 'jack johnson', 1176750529, 3413], ["Wake Forest Demon Deacons men's soccer", 'Burna Boy', 1260577388, 26745]]
        self.assertEqual(unique_authors(2, team_search_result), [['USC Trojans volleyball', 'jack johnson', 1218049435, 5525], ['Will Johnson (soccer)', 'Burna Boy', 1218489712, 3562]])
        ruby_search_result =  [['Ruby (programming language)', 'Bearcat', 1193928035, 30284]]
        self.assertEqual(unique_authors(-5, ruby_search_result), [])
        search_result_77 = []
        self.assertEqual(unique_authors(20, search_result_77), [])

    '''
    This function tests the function most_recent_article. This function takes one argument, a 2D list(metadata). It returns list with the most recent article.
    '''
    def test_most_recent_article(self):
       black_search_results =  [['2009 in music', 'RussBot', 1235133583, 69451], ['Rock music', 'Mack Johnson', 1258069053, 119498], ['Black dog (ghost)', 'Pegship', 1220471117, 14746], ['List of dystopian music, TV programs, and games', 'Bearcat', 1165317338, 13458], ['Georgia Bulldogs football', 'Burna Boy', 1166567889, 43718], ['Fisk University', 'RussBot', 1263393671, 16246], ['Landseer (dog)', 'Bearcat', 1231438650, 2006]]
       self.assertEqual(most_recent_article(black_search_results),['Fisk University', 'RussBot', 1263393671, 16246] )
       empty_search_result = []
       self.assertEqual(most_recent_article(empty_search_result), [])
       enemies_search_result = [['Spawning (computer gaming)', 'jack johnson', 1176750529, 3413]]
       self.assertEqual(most_recent_article(enemies_search_result), ['Spawning (computer gaming)', 'jack johnson', 1176750529, 3413])

    '''
    This function tests the function favorite_author. This function takes two arguments a string(favorite author) and a 2D list(metadata). It returns True if the favorited author is in the 2D list and False otherwise.
    '''
    def test_favorite_author(self):
        were_search_results = [['Kevin Cadogan', 'Mr Jake', 1144136316, 3917], ['Rock music', 'Mack Johnson', 1258069053, 119498], ['Lights (musician)', 'Burna Boy', 1213914297, 5898], ['Human computer', 'Bearcat', 1248275178, 4750], ['Black dog (ghost)', 'Pegship', 1220471117, 14746], ['Embryo drawing', 'Jack Johnson', 1034459202, 1712], ['Old-time music', 'Nihonjoe', 1124771619, 12755], ['Arabic music', 'RussBot', 1209417864, 25114], ['Richard Wright (musician)', 'RussBot', 1189536295, 16185], ['Dalmatian (dog)', 'Mr Jake', 1207793294, 26582], ['Guide dog', 'Jack Johnson', 1165601603, 7339], ['List of dystopian music, TV programs, and games', 'Bearcat', 1165317338, 13458], ['Steve Perry (musician)', 'Nihonjoe', 1254812045, 22204], ['Georgia Bulldogs football', 'Burna Boy', 1166567889, 43718], ['Time travel', 'Jack Johnson', 1140826049, 35170], ['Annie (musical)', 'Jack Johnson', 1223619626, 27558], ['Alex Turner (musician)', 'jack johnson', 1187010135, 9718], ['Indian classical music', 'Burna Boy', 1222543238, 9503], ['Sun dog', 'Mr Jake', 1208969289, 18050], ['Lua (programming language)', 'Burna Boy', 1113957128, 0], ['Personal computer', 'Pegship', 1220391790, 45663], ['Digital photography', 'Mr Jake', 1095727840, 18093], ['Sean Delaney (musician)', 'Nihonjoe', 1204328174, 5638], ['Ruby (programming language)', 'Bearcat', 1193928035, 30284]]
        self.assertEqual(favorite_author('BuRnA BOY', were_search_results), True)
        self.assertEqual(favorite_author('TeLETUBIES', were_search_results), False)
        empty_search_result = []
        self.assertEqual(favorite_author('Brent Faiyaz', empty_search_result), False)

    '''
    This function tests the function title_and_author. This function takes one argument a 2D list(metadata). It returns the article and author from each list in metadata.
    '''
    def test_title_and_author(self):
        blues_search_results = [['List of Canadian musicians', 'Jack Johnson', 1181623340, 21023], ['Rock music', 'Mack Johnson', 1258069053, 119498], ['2008 in music', 'Burna Boy', 1217641857, 107605]]
        self.assertEqual(title_and_author(blues_search_results),[('List of Canadian musicians', 'Jack Johnson'), ('Rock music', 'Mack Johnson'), ('2008 in music', 'Burna Boy')])
        hello_search_results = []
        self.assertEqual(title_and_author(hello_search_results), [])
        empty_search_result = []
        self.assertEqual(title_and_author(empty_search_result), [])

    '''
    This function tests the function refine_search. This function takes two arguments a string(keyword) and a 2D list(metadata). It returns the similar articles between the metadata and the search result of the keyword.
    '''
    def test_refine_search(self):
        band_search_results = [['List of Canadian musicians', 'Jack Johnson', 1181623340, 21023], ['Kevin Cadogan', 'Mr Jake', 1144136316, 3917], ['2009 in music', 'RussBot', 1235133583, 69451], ['Rock music', 'Mack Johnson', 1258069053, 119498], ['Lights (musician)', 'Burna Boy', 1213914297, 5898], ['Old-time music', 'Nihonjoe', 1124771619, 12755], ['Richard Wright (musician)', 'RussBot', 1189536295, 16185], ['List of dystopian music, TV programs, and games', 'Bearcat', 1165317338, 13458], ['Steve Perry (musician)', 'Nihonjoe', 1254812045, 22204], ['Alex Turner (musician)', 'jack johnson', 1187010135, 9718], ['1996 in music', 'Nihonjoe', 1148585201, 21688], ['David Levi (musician)', 'Gary King', 1212260237, 3949], ['2006 in music', 'Jack Johnson', 1171547747, 105280], ['Sean Delaney (musician)', 'Nihonjoe', 1204328174, 5638], ['Tony Kaye (musician)', 'Burna Boy', 1141489894, 8419], ['2007 in music', 'Bearcat', 1169248845, 45652], ['2008 in music', 'Burna Boy', 1217641857, 107605]]
        self.assertEqual(refine_search('mUsIc', band_search_results), [['List of Canadian musicians', 'Jack Johnson', 1181623340, 21023], ['Kevin Cadogan', 'Mr Jake', 1144136316, 3917], ['2009 in music', 'RussBot', 1235133583, 69451], ['Rock music', 'Mack Johnson', 1258069053, 119498], ['Lights (musician)', 'Burna Boy', 1213914297, 5898], ['Old-time music', 'Nihonjoe', 1124771619, 12755], ['Richard Wright (musician)', 'RussBot', 1189536295, 16185], ['List of dystopian music, TV programs, and games', 'Bearcat', 1165317338, 13458], ['Steve Perry (musician)', 'Nihonjoe', 1254812045, 22204], ['Alex Turner (musician)', 'jack johnson', 1187010135, 9718], ['1996 in music', 'Nihonjoe', 1148585201, 21688], ['2006 in music', 'Jack Johnson', 1171547747, 105280], ['Tony Kaye (musician)', 'Burna Boy', 1141489894, 8419], ['2007 in music', 'Bearcat', 1169248845, 45652], ['2008 in music', 'Burna Boy', 1217641857, 107605]])
        school_search_results = [['Edogawa, Tokyo', 'jack johnson', 1222607041, 4526], ['Fisk University', 'RussBot', 1263393671, 16246], ['Annie (musical)', 'Jack Johnson', 1223619626, 27558], ['Alex Turner (musician)', 'jack johnson', 1187010135, 9718]]
        self.assertEqual(refine_search('TeAM', school_search_results), [])
        vocal_search_result = []
        self.assertEqual(refine_search('KaLI uChIS', vocal_search_result), [])

    #####################
    # INTEGRATION TESTS #
    #####################

    @patch('builtins.input')
    def test_example_integration_test(self, input_mock):
        keyword = 'soccer'
        advanced_option = 1
        advanced_response = 3000
        
        output = get_print(input_mock, [keyword, advanced_option, advanced_response])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + str(advanced_response) + "\n\nHere are your articles: [['Spain national beach soccer team', 'jack johnson', 1233458894, 1526], ['Steven Cohen (soccer)', 'Mack Johnson', 1237669593, 2117]]\n"
        
        self.assertEqual(output, expected)

    '''
    This function tests the function unique_authors. This function takes in 2 arguments, one integer(the count) and one 2D list(metadata). It returns a 2D list with the count amount of articles all with different authors.
    '''
    @patch('builtins.input')
    def test_integration_unique_actors_function(self, input_mock):
        keyword = 'pop'
        advanced_option = 2
        advanced_response = 50
        
        output = get_print(input_mock, [keyword, advanced_option, advanced_response])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + str(advanced_response) + "\n\nHere are your articles: [['List of Canadian musicians', 'Jack Johnson', 1181623340, 21023], ['French pop music', 'Mack Johnson', 1172208041, 5569], ['2009 in music', 'RussBot', 1235133583, 69451]]\n"
        
        self.assertEqual(output, expected)

    '''
    This function tests the function most_recent_article. This function takes one argument, a 2D list(metadata). It returns list with the most recent article.
    '''
    @patch('builtins.input')
    def test_integration_most_recent_article_function(self, input_mock):
        keyword = 'bat'
        advanced_option = 3
       
        output = get_print(input_mock, [keyword, advanced_option])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + "\n\nHere are your articles: ['Mexican dog-faced bat', 'Mack Johnson', 1255316429, 1138]\n"
        
        self.assertEqual(output, expected)
    
    '''
    This function tests the function favorite_author. This function takes two arguments a string(favorite author) and a 2D list(metadata). It returns True if the favorited author is in the 2D list and False otherwise.
    '''
    @patch('builtins.input')
    def test_integration_favorite_author_function(self, input_mock):
        keyword = 'from'
        advanced_option = 4
        advanced_response = 'BurNA boY'
        
        output = get_print(input_mock, [keyword, advanced_option, advanced_response])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + str(advanced_response) + "\n\nHere are your articles: [['Noise (music)', 'jack johnson', 1194207604, 15641], ['Kevin Cadogan', 'Mr Jake', 1144136316, 3917], ['2009 in music', 'RussBot', 1235133583, 69451], ['Rock music', 'Mack Johnson', 1258069053, 119498], ['Lights (musician)', 'Burna Boy', 1213914297, 5898], ['Human computer', 'Bearcat', 1248275178, 4750], ['List of overtone musicians', 'Mack Johnson', 1176928050, 2299], ['Black dog (ghost)', 'Pegship', 1220471117, 14746], ['2007 Bulldogs RLFC season', 'Burna Boy', 1177410119, 11116], ['Embryo drawing', 'Jack Johnson', 1034459202, 1712], ['Old-time music', 'Nihonjoe', 1124771619, 12755], ['Arabic music', 'RussBot', 1209417864, 25114], ['C Sharp (programming language)', 'Burna Boy', 1232492672, 52364], ['B (programming language)', 'jack johnson', 1196622610, 5482], ['Richard Wright (musician)', 'RussBot', 1189536295, 16185], ['Dalmatian (dog)', 'Mr Jake', 1207793294, 26582], ['Guide dog', 'Jack Johnson', 1165601603, 7339], ['List of dystopian music, TV programs, and games', 'Bearcat', 1165317338, 13458], ['Steve Perry (musician)', 'Nihonjoe', 1254812045, 22204], ['2009 Louisiana Tech Bulldogs football team', 'Nihonjoe', 1245796406, 22410], ['Georgia Bulldogs football', 'Burna Boy', 1166567889, 43718], ['Time travel', 'Jack Johnson', 1140826049, 35170], ['Fisk University', 'RussBot', 1263393671, 16246], ['Annie (musical)', 'Jack Johnson', 1223619626, 27558], ['Alex Turner (musician)', 'jack johnson', 1187010135, 9718], ['Python (programming language)', 'Burna Boy', 1137530195, 41571], ['Indian classical music', 'Burna Boy', 1222543238, 9503], ['Sun dog', 'Mr Jake', 1208969289, 18050], ['1996 in music', 'Nihonjoe', 1148585201, 21688], ['Lua (programming language)', 'Burna Boy', 1113957128, 0], ['Joseph Williams (musician)', 'Pegship', 1140752684, 4253], ['The Hunchback of Notre Dame (musical)', 'Nihonjoe', 1192176615, 42], ['Covariance and contravariance (computer science)', 'Bearcat', 1167547364, 7453], ['Personal computer', 'Pegship', 1220391790, 45663], ['Digital photography', 'Mr Jake', 1095727840, 18093], ['Traditional Thai musical instruments', 'Jack Johnson', 1191830919, 6775], ['2006 in music', 'Jack Johnson', 1171547747, 105280], ['Sean Delaney (musician)', 'Nihonjoe', 1204328174, 5638], ['Tony Kaye (musician)', 'Burna Boy', 1141489894, 8419], ['Ruby (programming language)', 'Bearcat', 1193928035, 30284], ['Mode (computer interface)', 'Pegship', 1182732608, 2991], ['2007 in music', 'Bearcat', 1169248845, 45652], ['2008 in music', 'Burna Boy', 1217641857, 107605], ['Semaphore (programming)', 'Nihonjoe', 1144850850, 7616]]\n" + "Your favorite author is in the returned articles!\n"
        
        self.assertEqual(output, expected)

    '''
    This function tests the function title_and_author. This function takes one argument a 2D list(metadata). It returns the article and author from each list in metadata.
    '''
    @patch('builtins.input')
    def test_integration_title_and_author_function(self, input_mock):
        keyword = 'have'
        advanced_option = 5
        
        output = get_print(input_mock, [keyword, advanced_option])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + "\n\nHere are your articles: [('Noise (music)', 'jack johnson'), ('Kevin Cadogan', 'Mr Jake'), ('2009 in music', 'RussBot'), ('Rock music', 'Mack Johnson'), ('Black dog (ghost)', 'Pegship'), ('Old-time music', 'Nihonjoe'), ('Arabic music', 'RussBot'), ('C Sharp (programming language)', 'Burna Boy'), ('Voice classification in non-classical music', 'RussBot'), ('Dalmatian (dog)', 'Mr Jake'), ('Guide dog', 'Jack Johnson'), ('List of dystopian music, TV programs, and games', 'Bearcat'), ('Georgia Bulldogs football', 'Burna Boy'), ('Time travel', 'Jack Johnson'), ('Annie (musical)', 'Jack Johnson'), ('Alex Turner (musician)', 'jack johnson'), ('Python (programming language)', 'Burna Boy'), ('Indian classical music', 'Burna Boy'), ('Covariance and contravariance (computer science)', 'Bearcat'), ('Personal computer', 'Pegship'), ('Digital photography', 'Mr Jake'), ('Comparison of programming languages (basic instructions)', 'RussBot'), ('2006 in music', 'Jack Johnson'), ('Sean Delaney (musician)', 'Nihonjoe'), ('Mode (computer interface)', 'Pegship')]\n"
        
        self.assertEqual(output, expected)
    
    '''
    This function tests the function refine_search. This function takes two arguments a string(keyword) and a 2D list(metadata). It returns the similar articles between the metadata and the search result of the keyword.
    '''
    @patch('builtins.input')
    def test_integration_refine_search_function(self, input_mock):
        keyword = 'composer'
        advanced_option = 6
        advanced_response = 'music'
        
        output = get_print(input_mock, [keyword, advanced_option, advanced_response])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + '\n' + print_advanced_option(advanced_option) + str(advanced_response) + "\n\nHere are your articles: [['List of Canadian musicians', 'Jack Johnson', 1181623340, 21023], ['1922 in music', 'Gary King', 1242717698, 11576], ['1986 in music', 'jack johnson', 1048918054, 6632], ['2009 in music', 'RussBot', 1235133583, 69451], ['1936 in music', 'RussBot', 1243745950, 23417], ['1996 in music', 'Nihonjoe', 1148585201, 21688], ['2006 in music', 'Jack Johnson', 1171547747, 105280], ['2007 in music', 'Bearcat', 1169248845, 45652], ['2008 in music', 'Burna Boy', 1217641857, 107605]]\n"
        
        self.assertEqual(output, expected)
    
    '''
    This function tests the function search, this function takes in one argument and returns a 2D list of all the articles relqated to said keyword
    '''
    @patch('builtins.input')
    def test_integration_search_function(self, input_mock):
        keyword = 'key'
        advanced_option = 7
        
        output = get_print(input_mock, [keyword, advanced_option])
        expected = print_basic() + keyword + '\n' + print_advanced() + str(advanced_option) + "\n\nHere are your articles: [['Rock music', 'Mack Johnson', 1258069053, 119498], ['Lua (programming language)', 'Burna Boy', 1113957128, 0], ['Mode (computer interface)', 'Pegship', 1182732608, 2991]]\n"
        
        self.assertEqual(output, expected)


# Write tests above this line. Do not remove.
if __name__ == "__main__":
    main()
